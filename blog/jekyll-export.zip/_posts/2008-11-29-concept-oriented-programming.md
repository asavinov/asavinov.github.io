---
id: 13
title: Concept-Oriented Programming
date: 2008-11-29T13:53:55+00:00
author: savinov
excerpt: 'Concept-oriented programming (CoP) is a next generation programming paradigm. It is based on using concepts as the main programming construct. A concept is a pair of two classes: an object class and a reference class. Instances of the object class, objec&hellip;'
layout: post
permalink: /?p=13
categories:
  - cop
  - Uncategorized
---
Concept-oriented programming (COP) is a next generation programming paradigm. It is based on using concepts as the main programming construct. A concept is a pair of two classes: an object class and a reference class. Instances of the object class, objects, are passed by reference. Instances of the reference class, references, are passed by value and are intended to indirectly represent objects. Each concept has a parent concept, called superconcept, specified via inclusion relation. A concept has also a pair of special continuation methods (for both the object class and the reference class), which are used to organize a reference resolution and object access.

A concept-oriented program uses concepts instead of classes (a concept with the empty reference class is equivalent to the conventional class as defined in OOP). The idea of COP is that superconcepts provide a level of indirection for their subconcepts. They play a role of environment or container. In particular, they provide a custom format of references and custom access procedures. In COP we never know what is the object reference format and where does it reside. Such a simple method invocation as <tt>myObject.myMethod()</tt> my trigger rather complex intermediate functions, which are executed behind the scenes. The object itself may reside anywhere in the world &#8211; it depends on its superconcepts. For example, we might develop concepts for managing a huge number of tiny objects, for persistent objects, for remote objects etc. The idea is that this hidden level of RA functionality has to be an integral part of the program because it account for a great deal and even most of its complexity.

COP complements the concept-oriented data model (COP) and is being developed as a part of the concept-oriented paradigm. More information on COP and other related new technologies can be found on the concept-oriented portal: <http://conceptoriented.org>. In particular, it has an article describing in details what is a concept and how it is used in COP. Questions and opinions can be written in a new concept-oriented forum: <http://conceptoriented.org/forums/index.php>.