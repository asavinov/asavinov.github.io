---
id: 19
title: Modelling hierarchical address space in the concept-oriented programming (COP)
date: 2008-11-29T14:05:41+00:00
author: savinov
excerpt: '1. Let us assume that objects are represented by references in a custom format defined by the programmer. For example, bank accounts could be represented by their numbers. In the concept-oriented programming (COP) a special construct, called concept, i&hellip;'
layout: post
permalink: /?p=19
categories:
  - cop
  - Uncategorized
---
**1.**
  
Let us assume that objects are represented by references in a custom format defined by the programmer. For example, bank accounts could be represented by their numbers. In the [concept-oriented programming](http://conceptoriented.org/wiki/Concept-oriented_programming) (COP) a special construct, called [concept](http://conceptoriented.org/wiki/Concept_(concept-oriented_programming)), is used for this purpose. Concept is a pair of two classes &#8212; one reference class and one object class. With the empty reference class, concept is equivalent to normal classes as used in OOP. However, below we ignore properties of the object class and discuss only role of the reference class &#8212; precisely what distinguishes concepts from conventional classes.

Reference class in concepts is a mechanism for defining custom references of objects. For example, if we need to represent account objects by account numbers (rather than by native references) then the reference class has one field which stores this account number:

<pre><b>concept</b> Account 
    <b>reference</b> { 
        String accNo; 
        ... 
    } 
    <b>object</b> { 
        double balance; 
        ... 
    }</pre>

Notice that the name is assigned to the whole concept, i.e., to the pair of one object class and one reference class, which essentially loose their role as separate constructs and work only together in close cooperation. In other words, we do not define separately a reference class but rather simultaneously two classes with one name. It is a very important feature of the whole concept-oriented paradigm.

Now, if we use concept `Account` for declaring type of variables then accounts will be stored and passed by means of their numbers rather than using native references like memory address in C++:

<pre>Account account = getAccount("Alexandr Savinov"); // Account number</pre>

Here variable `account` stores an account number. If `Account` were a normal class then it would store a native reference. Thus object representation and access in COP is _indirect_.

**2.**
  
Using one concept (or one class) we can define a _flat_ address spaces where objects of one class are represented by references of the associated class (reference class from the concept). Yet frequently we need to describe a _hierarchical_ address spaces where a reference is only one segment in the address. In other words, each segment in a hierarchical address specifies a relative position of the object with respect to the parent segment which in turn is a relative position with respect to its own parent segment and so on till the root of the address space. Such address space is analogous to ordinary postal addresses.

For modelling such hierarchical spaces, COP uses [inclusion relation](http://conceptoriented.org/wiki/Inclusion_(concept-oriented_programming)), which generalizes class inheritance just as concepts generalize classes. Parent address space for this concept is specified by including it into some parent concept. For example, bank account numbers are only relative identifiers which make sense only in one bank. Hence, if we want to deal with accounts of different banks then it is necessary to define two-segment addresses where first (high) segment is bank code and the second (low) segment is account number within this bank. This can be easily done in COP as follows:

<pre><b>concept</b> Bank 
    <b>reference</b> { 
        String bankCode; 
        ... 
    } 
    <b>object</b> { 
        String name; 
        ... 
    } 
    
<b>concept</b> Account <b>in</b> Bank ...</pre>

Notice that concept `Account` is included into parent concept `Bank`. As a consequence, references to bank accounts will &#8216;inherit&#8217; all fields from the parent reference (yet, it is not so for objects). Such references are referred to as [complex references](http://conceptoriented.org/wiki/Complex_reference). Now if we declare a variable of type `Account`, it will store two segments taken from reference classes of two concepts:

<pre>Account account = getAccount("Alexandr Savinov"); // Bank code + Account number</pre>

**3.**
  
This hierarchical address space can be further extended in the other direction. Assume that bank accounts have sub-accounts like savings accounts or checking accounts, which are defined only with respect to the main account. To represent and access such objects it is necessary to provide bank code, main account number and finally sub-account number. Again this can be done by including child concept into concept `Account`:

<pre><b>concept</b> SavingsAccount <b>in</b> Account 
    <b>reference</b> { 
        String subAccNo; 
        ... 
    } 
    <b>object</b> { 
        double balance; 
        ... 
    } 
    
<b>concept</b> CheckingAccount <b>in</b> Account 
    <b>reference</b> { 
        String subAccNo; 
        ... 
    } 
    <b>object</b> { 
        double balance; 
        ... 
    }</pre>

If we declare a variable of this more specific type then it will store references consisting of three segments:

<pre>SavingsAccount savingsAccount; // Bank + Account + SavingsAccount 
CheckingAccount checkingAccount; // Bank + Account + CheckingAccount</pre>

**4.**
  
Notice that references stored in these variables do not contain any information on the real location of the represented objects. This means that these objects can be anywhere in the world: on disk/tape in the bank, in a database, on CD, in global/local heap, on board of International Space Station or on Mars. This is why objects in COP are said to be represented _indirectly_ and the whole approach is devoted to providing means for _indirect_ object representation and access (ORA).

However, in the program we manipulate objects as if they were _directly_ accessible objects in OOP. In other words, we have a complete illusion of direct access because we still can apply methods to such references or access them in any other way. For example, we might get account balance, `account.getBalance()`, and here we do not care what kind of reference is stored in the variable and used for access. Thus use of objects does not depend on their representation method. If later we change the way objects are represented then the code that uses these objects remains the same.

Another important property is that inclusion is significantly different from inheritance. The thing is that inclusion means that a child element IS-IN a parent element at run-time, i.e., one parent (base) may have many children (extensions). In OOP inheritance means that a child IS-A parent element and hence extensions and bases are in one-to-one relationship. In COP elements (objects and references) exist within a hierarchy at run-time where extensions have their own references and may share base elements. Local reference of an extension allows distinguishing it from other extensions within this base element.

The third point is that complex references need not to start from the root. If we were using inheritance for describing complex references (for inheriting base segments of the address) then all references would have global scope. In COP it is possible to control the length (and hence scope) of references by choosing the starting segment type. It is very useful feature if we know that some reference will be used only in a restricted context. For example, it is obviously not necessary to store bank reference segment if the account is used within this bank only. This mechanism of reference length control will be described in future posts.

&#8212;
  
 <http://conceptoriented.org>