---
id: 31
title: What if references are active elements of the program?
date: 2009-04-09T05:27:10+00:00
author: savinov
excerpt: But what if we assume that references, like objects, may have arbitrary domain-specific structure and behavior? Shortly, we will get a novel approach, called concept-oriented programming (COP).
layout: post
permalink: /?p=31
categories:
  - cop
  - Uncategorized
tags:
  - active references
  - concept-oriented programming
  - domain-specific references
---
In programming, we used to think of references are something primitive and platform-specific that is provided by the compiler as a means for representing objects. In contrast to objects, which have domain-specific structure and behavior, references do not expose their structure and do not show any activity. We use objects represented by references as if they were directly accessible and programming is reduced to modeling exclusively objects while references are absolutely passive elements.

But what if we assume that references, like objects, may have arbitrary domain-specific structure and behavior? Shortly, we will get a novel approach, called [concept-oriented programming](http://conceptoriented.org/wiki/Concept-oriented_programming) (COP). References in COP are as important as objects because _both_ can modularize domain-specific structure and behavior. The first question here is what advantages we will get by using active references? Here are some applications where it could be useful:

  * Modeling [domain-specific address space](http://conceptoriented.org/blogs/cob/2007/06/12/modelling-hierarchical-address-space-in) rather than adapting platform-specific surrogates. Indeed, why not to use domain-specific references directly in the program to identify its objects? It is simpler and more natural.
  * Modeling [cross-cutting concerns](http://conceptoriented.org/blogs/cob/2007/05/29/concept-oriented-programming-vs-aspect-o). An important observation about references is that their functions cross-cut many classes of objects. For example, when a Java object is being accessed, JVM executes one and the same procedure independent of the object class. If references could be modeled from the program then we could use them to execute functions which are common to many object classes.
  * Modeling persistent, remote and transactional objects. References could be responsible for implementing intermediate functionality which is specific to these uses. For example, each time an object is about to be accessed, its reference will load its state from persistent storage or send the request to its remote location or start a transaction.

**COP Article:** [Informal Introduction into the Concept-Oriented Programming](http://conceptoriented.org/papers/CopInformalIntroduction.html)
  
**COP forum:** <http://conceptoriented.org/forums/index.php>