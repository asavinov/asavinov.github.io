---
id: 7
title: FAQ on the Concept-Oriented Query Language (COQL) has been added
date: 2008-11-29T13:49:29+00:00
author: savinov
excerpt: 'I have just added new FAQ into my conceptoriented.org portal, which answers simple questions concerning the Concept-Oriented Query Language (CoQL). CoQL is one possible query language suitable for the use in the concept-oriented data model. I also st&hellip;'
layout: post
permalink: /?p=7
categories:
  - com
  - Uncategorized
---
I have just added new FAQ into my [conceptoriented.org](http://conceptoriented.org/) portal, which answers simple questions concerning the Concept-Oriented Query Language (COQL). COQL is one possible query language suitable for the use in the concept-oriented data model.

I also started a thread in <http://www.dbforums.com/> where this model can be discussed. Here is the link: <http://www.dbforums.com/t1072076.html>