---
id: 4
title: The Concept-Oriented Portal
date: 2008-11-29T13:44:25+00:00
author: savinov
excerpt: 'Today I started my own web site http://conceptoriented.org/ for collecting all information about the concept-oriented approach to programming, database model, analysis and design. Currently it includes only very limited information on the concept-oriente&hellip;'
layout: post
permalink: /?p=4
categories:
  - Uncategorized
---
Today I started my own web site <a href="http://conceptoriented.org/" target="_blank">http://conceptoriented.org/</a> for collecting all information about the concept-oriented approach to programming, database model, analysis and design. Currently it includes only very limited information on the concept-oriented data model (COM) but I will try to update this site regularly. The next thing is to add more information on the general concept-oriented principles and COM faq.