---
id: 5
title: FAQ on the concept-oriented principles (philosophy)
date: 2008-11-29T13:46:27+00:00
author: savinov
excerpt: 'Today I added the first FAQ to my concept-oriented portal. The concept-oriented paradigm is based on a set of general principles. In particular, these principles describe what objects are, where do they live, how they are represented and accessed. Al&hellip;'
layout: post
permalink: /?p=5
categories:
  - Uncategorized
---
Today I added the first FAQ to my concept-oriented [portal](http://conceptoriented.org/).

The concept-oriented paradigm is based on a set of general principles. In particular, these principles describe what objects are, where do they live, how they are represented and accessed. Although these principle are of very general and even somewhat philosophical character they are quite important for understanding the basics of more concrete mechanisms such as concept-oriented programming (COP), concept-oriented database model (CODBM) and concept-oriented design. In particular, these principles are useful in understanding differences from the existing paradigms such as the object-oriented one.

The next FAQ will be on the concept-oriented data model (COM).