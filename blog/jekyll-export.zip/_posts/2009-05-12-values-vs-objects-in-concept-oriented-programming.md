---
id: 32
title: Values vs. objects in concept-oriented programming (COP)
date: 2009-05-12T04:16:57+00:00
author: savinov
excerpt: Values are opposed to objects but they have different level of support in OOP. In concept-oriented programming (COP) both values and objects have equal rights because they are two sides of one element. COP uses concepts to describe its elements where a concept is a couple consisting of one reference class and one object class. Inclusion relation is used in COP instead of classical inheritance so that one base can be shared among many extensions.
layout: post
permalink: /?p=32
categories:
  - cop
  - Uncategorized
tags:
  - concept-oriented programming
  - cop
  - hierarchical address space
  - inclusion relation
  - objects
  - references
  - values
---
Values are opposed to objects because they have opposite properties, that is, values are not objects and objects are not values. For example, a value is immutable element which is passed by-copy (by-value) while objects are passed by-reference. In programming languages, values are normally stored in stack while objects are allocated in heap. Values are visible from and used by only this context while objects can be shared by many contexts. Values do not have a location in space (reference) while objects are characterized by a permanent reference.

Since OOP is about objects, values are not fully supported in this programming paradigm. In particular, the main purpose of classes in OOP consists in describing object types rather than value types. The only thing that is supported in most programming languages are primitive values with primitive types like integers. Another very important use of values supported in most OO languages is referencing. However, we are not able to create application-specific values and application-specific references &#8212; they have a platform-specific format and behavior. (One exception is C++ where classes can be used for describing both values and objects.)

In the [concept-oriented programming](http://conceptoriented.org/wiki/Concept-oriented_programming) (COP), both values and objects are first class citizens with the same rights. It is not simply a decorative enhancement but the recognition of the importance of values. Values in COP can account for a great deal or even most the program complexity.

For modeling values and objects COP introduces a novel programming construct, called [concept](http://conceptoriented.org/wiki/Concept_%28concept-oriented_programming%29). Concept is defined as a couple of two classes: one reference class _and_ one object class. Reference class describes values while object class describes objects. (We call it reference class because the main role of values is a reference.) What is really new here is that these two classes cannot be used separately, that is, reference class and object class is one whole. The change of paradigm is that programming is reduced to manipulating value-object _couples_. In this context, COP informally relates to OOP as complex numbers relate to real numbers in mathematics. If in OOP elements have only one constituent &#8212; an object, then in COP an element has always two constituents &#8212; one value _and_ one object, which are informally analogous to two constituents of complex numbers (imaginary and real part).

The next change is that [inclusion relation](http://conceptoriented.org/wiki/Inclusion_%28concept-oriented_programming%29) is used instead of classical inheritance. In OOP terms, this means that a base element (value-object couple) may have many extensions. If values are used as references, then it is a basis for describing application-specific [hierarchical address spaces](http://conceptoriented.org/blogs/cob/2007/06/12/modelling-hierarchical-address-space-in) like conventional postal addresses. For example, assume that concept `Street` is included in concept `City` which in turn is included in `Country`. After that each element is represented by a reference consisting of three segments: country (high), city (middle), street (low). This complex reference is a value which represents a complex object. The main different from OOP is that one country (base) can be shared among many cities (extensions) which in turn can be shared among many streets. Elements in COP are living in a hierarchical space (described by concept inclusion hierarchy) while in OOP they are living in a flat space although their classes are hierarchically ordered.

**COP Article:** [Informal Introduction into the Concept-Oriented Programming](http://conceptoriented.org/papers/CopInformalIntroduction.html)
  
**COP forum:** <http://conceptoriented.org/forums/index.php>