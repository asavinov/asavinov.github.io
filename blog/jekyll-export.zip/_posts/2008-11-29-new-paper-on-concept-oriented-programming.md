---
id: 17
title: New paper on concept-oriented programming
date: 2008-11-29T14:00:51+00:00
author: savinov
excerpt: 'An Approach to Programming Based on ConceptsAbstractIn this paper we describe a new approach to programming which generalizes object-oriented programming. It is based on using a new programming construct, called concept, which generalizes classes&hellip;'
layout: post
permalink: /?p=17
categories:
  - cop
  - Uncategorized
---
**An Approach to Programming Based on Concepts**

Abstract

In this paper we describe a new approach to programming which generalizes object-oriented programming. It is based on using a new programming construct, called concept, which generalizes classes. Concept is defined as a pair of two classes: one reference class and one object class. Each concept has a parent concept which is specified using inclusion relation generalizing inheritance. We describe several important mechanisms such as reference resolution, context stack, dual methods and life-cycle management, inheritance and polymorphism. This approach to programming is positioned as a new programming paradigm and therefore we formulate its main principles and rules.

Table of contents:
  
1 Introduction 2
  
2 Representation and Access 3
  
2.1 Entities and Identities 3
  
2.2 Inclusion Relation 5
  
2.3 Substitution Relation 7
  
3 Concepts for Describing Entities and Identities 8
  
3.1 Reference Class and Object Class 8
  
3.2 Concept Definition 9
  
3.3 Meta-Transition 12
  
4 Concept Inclusion 14
  
4.1 Complex References 14
  
4.2 Sequence of Access 16
  
4.3 Context Stack 20
  
4.4 Life-Cycle Management 22
  
5 Operations with References 25
  
5.1 Reference Structure and Parameters 25
  
5.2 Left and Right Casting 27
  
5.3 Reference Length Control 28
  
6 CoP as a Generalization of OOP 30
  
6.1 Inheritance 30
  
6.2 Polymorphism 32
  
6.3 Object Construction and Deletion 34
  
7 Principles of the Concept-Oriented Paradigm 35
  
7.1 There is Always Something in-between 35
  
7.2 There is Always Something out There 36
  
7.3 Everything Has an Identity and Entity 37
  
7.4 Everything is Relative and Virtual 39
  
8 Related Work 39
  
8.1 Hardware Level 39
  
8.2 Software Level 40
  
8.3 Design Patterns 41
  
8.4 Language Level 42
  
8.5 Conceptual Approaches 45
  
8.6 Concept Related Approaches 46
  
9 Conclusions 47
  
10 References 47

This and other papers can be downloaded from  <http://conceptoriented.org> (section Publications) or directly [here](http://conceptoriented.org/savinov/publicat/imi-report_07_2.pdf).