---
id: 6
title: FAQ on the concept-oriented data model (COM) has been added
date: 2008-11-29T13:48:00+00:00
author: savinov
excerpt: 'I have just added new FAQ into my conceptoriented.org portal. This new CoM FAQ answers such questions as what is the concept-oriented data model (CoM) syntax and semantics, what are concepts and items, dimensions and realationships, grouping and aggregat&hellip;'
layout: post
permalink: /?p=6
categories:
  - com
  - Uncategorized
---
I have just added new FAQ into my [conceptoriented.org](http://conceptoriented.org/) portal. This new COM FAQ answers such questions as what is the concept-oriented data model (COM) syntax and semantics, what are concepts and items, dimensions and realationships, grouping and aggregation. It also covers some implementation issues and provides a comparison with other database models and data modeling approaches.