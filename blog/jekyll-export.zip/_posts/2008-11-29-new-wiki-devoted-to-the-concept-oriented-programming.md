---
id: 24
title: New wiki devoted to the concept-oriented programming (COP)
date: 2008-11-29T14:18:05+00:00
author: savinov
excerpt: 'New wiki has been started on the concept-oriented portal. It contains a number of articles in the style of encyclopaedia defining main terms and notions used in the concept-oriented paradigm. In particular, in includes a category for the concept-oriented&hellip;'
layout: post
permalink: /?p=24
categories:
  - cop
  - Uncategorized
---
New [wiki](http://conceptoriented.org/wiki/) has been started on the [concept-oriented portal](http://conceptoriented.org/). It contains a number of articles in the style of encyclopaedia defining main terms and notions used in the concept-oriented paradigm. In particular, in includes a category for the [concept-oriented programming](http://conceptoriented.org/wiki/Category:Concept-oriented_programming) and a category for the [concept-oriented data model](http://conceptoriented.org/wiki/Category:Concept-oriented_model).