---
id: 18
title: Concept-oriented programming (COP) and smart pointers in C++
date: 2008-11-29T14:04:03+00:00
author: savinov
excerpt: '1. Modelling references in COP  In the concept-oriented programming (CoP) concepts are used instead of classes. A concept is a pair consisting of one reference class and one object class. Instances of the reference class are passed-by-value and are i&hellip;'
layout: post
permalink: /?p=18
categories:
  - cop
  - Uncategorized
---
**1. Modelling references in COP** 

In the [concept-oriented programming](http://conceptoriented.org/wiki/Concept-oriented_programming) (COP) concepts are used instead of classes. A [concept](http://conceptoriented.org/wiki/Concept_(concept-oriented_programming)) is a pair consisting of one reference class and one object class. Instances of the reference class are passed-by-value and are intended to represent instances of the object class. Thus objects and references always exist in pairs reflecting two sides of one and the same thing (identity and entity). For example, to describe bank accounts we could define concept Account:

<pre><b>concept</b> Account 
    <b>reference</b> { 
        String accNo; 
        ... 
    } 
    <b>object</b> { 
        double balance; 
        ... 
    }</pre>

Now, if we define a variable of this concept, it will contain an instance of this concept reference class (account number). In contrast, in OOP it would contain a direct primitive reference to an object in memory.

References can be viewed as intermediate elements or proxies. They intercept any access to the object. For example, if we apply some method to a variable, say, account.getBalance(), then it will be executed in the reference and only after that its execution can be continued in the object. Thus COP and concepts allow the programmer to effectively model custom references which provide a level of indirection but simulate normal references.

**2. Modelling references by smart pointers** 

The same result could be reached using an old C++ pattern called [smart pointers](http://en.wikipedia.org/wiki/Smart_pointer). The main goal of this technique consists in describing custom references by normal classes so that their instances then are used instead of direct references provided by the compiler. In C++ class instances can be passed-by-value and hence reference structure could be described by normal classes. (Notice that in Java it is not possible.) For example, account identifiers could be described as follows:

<pre>public <b>class</b> AccountRef { 
        String accNo; 
        ... 
    }</pre>

In order to create a new instance of account object, it is actually necessary to create two instances: one reference and one object. And hence it is necessary to provide two class names. However, to work properly, a reference class has to know about the object class. To pass this information, smart pointers use the mechanism of templates. Specifically, a reference class is defined as a template parameterized by the name of the objects class:

<pre><b>template</b> &lt; class T &gt; 
public <b>class</b> AccountRef { 
        String accNo; 
        T& operator-&gt;() const { ... }  // Access operator 
        ... 
    }</pre>

Thus smart pointer class does not know its concrete object class. Rather, it has a parameter that may take any value. In other words, a smart pointer class can be used to represent any object and one object can be represented by many reference classes. This pairing is performed when a new variable is declared, i.e., for each new variable we provide two concrete class names: one for the reference class and one for the object class:

<pre>AccountRef &lt; Account &gt; account(new Account);</pre>

This variable will store an instance of AccountRef parameterized for Account. Any operation is then applied to this smart pointer which overloads access operator (dot or arrow). Using this smart pointer we can transparently call methods of the represented object, say, account.getBalance(). Here we see that both COP and smart pointers allow the programmer to define custom references with arbitrary structure and behaviour which can be used as intermediate object representatives.

**3. Comparison** 

Although these two approaches look very similar, they are actually quite different.

  * Smart pointers is a technique or pattern that can be used only if templates are supported and the language permits pass-by-value semantics for objects. On the other hand, COP is a general purpose approach rather than a reference modelling technique.
  * Concepts in COP are intended to describe hierarchical virtual address spaces where objects will live while smart pointers play the role of interceptors for objects.
  * Smart pointers still use normal classes for modelling references by adapting them for certain purpose. So it is an implementation of some logic of behaviour. In COP, a new programming construct is used instead of classes which intrinsically supports the necessary functions rather than implements them by user-defined methods.
  * Reference class and object class in smart pointers are defined separately and can be then paired almost arbitrarily for specifying what object class has to be represented by what reference class. In COP, reference class and object class do not exist separately because they are parts of one construct. In this sense a reference class and object class are designed together from the very beginning and they cannot be freely paired.
  * Smart pointers assume that reference class and object class are paired many times when each new variable is declared (the problem of duplicated code). In COP, they are paired only once when the concept is defined while variables are declared using one concept name.
  * It is difficult to implement layered (hierarchical) references using smart pointers. In COP it is very easy and, moreover, COP is designed to describe hierarchies using [inclusion relation](http://conceptoriented.org/wiki/Inclusion_(concept-oriented_programming)) between concepts.
  * In COP, references can be reused by their child concepts. In other words, we can develop a concept which implements in its reference class some logic of indirect representation and then use it as a base concept for other concepts.
  * Smart smart pointers need special operators in language to distinguish by-value and by-reference semantics (like star and ampersand in C++) because classes to not have this role. In COP, the role of reference and object is built into concept.

&#8212;
  
 <http://conceptoriented.org>