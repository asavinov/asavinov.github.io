---
id: 14
title: FAQ on the concept-oriented programming (COP) updated
date: 2008-11-29T13:55:50+00:00
author: savinov
excerpt: 'I have added two new sections to CoP FAQ. The first added section on object creation and deletion answers questions concerning object life-cycle management. The second added section provides examples of Hello World programs which demonstrate various pr&hellip;'
layout: post
permalink: /?p=14
categories:
  - cop
  - Uncategorized
---
I have added two new sections to [COP FAQ](http://conceptoriented.org/faqs/cop-faq.html).
  
The first added section on object creation and deletion answers questions concerning object life-cycle management. The second added section provides examples of Hello World programs which demonstrate various principles of the concept-oriented programming.

More information on these and other concept-oriented
  
technologies can be found on the [
  
concept-oriented portal](http://conceptoriented.org/). In particular, questions on these next generation technologies can be asked on the recently opened
  
[forum](http://conceptoriented.org/forums/index.php).