New paper on the concept-oriented data model
############################################
:date: 2008-11-29 14:19
:author: savinov
:category: cop, Uncategorized
:slug: new-paper-on-the-concept-oriented-data-model
:status: published

**Two-Level Concept-Oriented Data Model**

Abstract

In this paper we describe a new approach to data modelling called the
concept-oriented model (CoM). This model is based on the formalism of
nested ordered sets which uses inclusion relation to produce
hierarchical structure of sets and ordering relation to produce
multi-dimensional structure among its elements. Nested ordered set is
defined as an ordered set where an each element can be itself an ordered
set. Ordering relation in CoM is used to define data semantics and
operations with data such as projection and de-projection. This data
model can be applied to very different problems and the paper describes
some its uses such grouping with aggregation and multi-dimensional
analysis.

Table of contents:

| 1 Introduction 2
| 2 One-Level Data Model 3
| 2.1 Labelled Ordered Sets 3
| 2.2 Interpretations of Ordering Relation 6
| 2.3 Representation of Labelled Ordered Sets 8
| 2.4 Operations with Elements 10
| 3 Two-Level Data Model 11
| 3.1 Nested Ordered Sets 11
| 3.2 Syntactic Constraints 12
| 3.3 Multidimensional Hierarchical Space 14
| 4 Operations with Model Semantics 16
| 4.1 Representing Model Semantics 16
| 4.2 Projection and De-Projection 19
| 4.3 Constraints and their Propagation 21
| 4.4 Dependencies and Inference 25
| 5 Uses of the Model 26
| 5.1 Query Language 26
| 5.2 Multi-Valued Properties 29
| 5.3 Grouping and Aggregation 30
| 5.4 Multi-Dimensional Analysis and OLAP 33
| 6 Related Work 35
| 7 Conclusions 38
| 8 References 38

This and other papers can be downloaded from http://conceptoriented.org
(section Publications) or directly
`here <http://conceptoriented.org/savinov/publicat/imi-report_07_3.pdf>`__.
