New wiki devoted to the concept-oriented programming (COP)
##########################################################
:date: 2008-11-29 14:18
:author: savinov
:category: cop, Uncategorized
:slug: new-wiki-devoted-to-the-concept-oriented-programming
:status: published

New `wiki <http://conceptoriented.org/wiki/>`__ has been started on the
`concept-oriented portal <http://conceptoriented.org/>`__. It contains a
number of articles in the style of encyclopaedia defining main terms and
notions used in the concept-oriented paradigm. In particular, in
includes a category for the `concept-oriented
programming <http://conceptoriented.org/wiki/Category:Concept-oriented_programming>`__
and a category for the `concept-oriented data
model <http://conceptoriented.org/wiki/Category:Concept-oriented_model>`__.
