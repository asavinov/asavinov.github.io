Dual methods in concept-oriented programming vs. capturing and bubbling in JavaScript
#####################################################################################
:date: 2012-03-25 11:32
:author: savinov
:category: cop, Uncategorized
:tags: bubbling, capturing, concept-oriented programming, cop, dual methods, event handling, incoming methods, javascript, outgoing methods, reverse overriding
:slug: dual-methods-in-concept-oriented-programming-vs-capturing-and-bubbling-in-javascript
:status: published

`JavaScript <http://en.wikipedia.org/wiki/Javascript>`__ is a
prototype-based language (like
`Self <http://en.wikipedia.org/wiki/Self_%28programming_language%29>`__)
the main use of which consists in implementing web applications by
adding behavior to HTML pages. A page is represented as a tree of
elements, called DOM model, where each element has one parent and many
child elements. The most important distinguishing feature of
prototype-based languages is that they do not use classes and parents
are shared parts of children. JavaScript implements an event-based
model. Events are created and processed in the context of DOM elements.
For example, if a DOM element represents some kind of panel then click
events will be associated with this element and then processed by a
handler attached to it.

Since DOM elements are nested the main question is in which direction
events should be processed: downwards in the direction of child elements
or upwards in the direction of the root element. The first (downward)
event propagation strategy where parent event handlers have precedence
over child handlers is referred to as *capturing*. The second (upward)
event propagation strategy where child handlers have precedence over
their parents is referred to as *bubbling*. For example, if we click a
button within a panel then which of them will process this event first:
the button (child) handler or the panel (parent) handler? These two
opposite approaches were implemented in different browsers: Netscape
chose the capturing (downward) model and Microsoft chose the bubbling
(upward) model. The `W3C event
model <http://www.w3.org/TR/2000/REC-DOM-Level-2-Events-20001113/>`__
supports both strategies so that event processing consists of two
phases: first capturing down to the target element and then bubbling
back up to the parent element.

.. raw:: html

   <div class="image_block">

|Dual methods in COP|

.. raw:: html

   </div>

`Concept-oriented
programming <http://conceptoriented.org/wiki/Concept-oriented_programming>`__
(COP) is similar to prototype-based languages in that objects in this
model also exist in a hierarchy. The difference is that COP is a
class-based approach where classes are used in a generalized form and
called
`concepts <http://conceptoriented.org/wiki/Concept_%28concept-oriented_programming%29>`__
(hence its name). Interestingly, COP has a novel method invocation model
which is similar to the event propagation model in JavaScript via
capturing and bubbling. This model is based on `dual
methods <http://conceptoriented.org/wiki/Dual_methods>`__ where each
method is defined two times and these two implementations are referred
to as *incoming* and *outgoing* methods. Incoming methods are executed
when they are called from outside (from the parent). Outgoing methods
are called when they are called from inside (from the child). Such a
composition means that incoming methods intercept all incoming calls
while outgoing methods intercept all outgoing calls. Essentially,
incoming methods implement what capturing does in JavaScript while
outgoing methods implement what bubbling does.

An advantage of dual methods is that there is only one predefined
sequence of access which is controlled by two types of methods. If we do
not want to intercept an event during capturing then we simply do not
define the corresponding incoming method and this level will be
transparent. And if we do not want to continue (capturing or bubbling)
then we simply do not call the next method in the sequence. So it can be
viewed as a method-based analogue of the event-based JavaScript model
where instead of two-phase event processing two kinds of methods are
used responsible for processing requests propagating in two opposite
directions. The same mechanism in COP is used for `reverse
overriding <http://www.jot.fm/issues/issue_2008_03/article2/>`__ and for
`modeling
aspects <http://conceptoriented.org/blogs/cob/2007/05/29/concept-oriented-programming-vs-aspect-o>`__.
Note also that the capturing model is also analogous to inner methods in
the Beta programming language.

| **Links:**
| `Bubbling and
  capturing <http://javascript.info/tutorial/bubbling-and-capturing>`__
| `Introduction to
  Events <http://www.quirksmode.org/js/introevents.html>`__
| `Event order <http://www.quirksmode.org/js/events_order.html>`__

.. |Dual methods in COP| image:: http://conceptoriented.org/blogs/wp-content/uploads/evo/dual_methods.png
   :width: 85.0%
