Three steps to understand the main idea of the concept-oriented programming (COP)
#################################################################################
:date: 2008-11-29 13:58
:author: savinov
:category: cop, Uncategorized
:slug: three-steps-to-understand-the-main-idea-of-the-concept-oriented-programming
:status: published

**Step 1**

Let us assume that there is a reference to an account object and we want
to get the account balance:

::

    Account account = customer.getAccount(); 
    double balance = account.getBalance();

In OOP variable account would contain a reference in some system default
format. In COP it may contain *any* data that *indirectly* represents
the account object.

**Step 2**

In order to describe the format of references the programmer can use
classes. Thus the program consists of two kinds of classes: object
classes and reference classes. Instances of the object classes are
passed-by-reference only while instances of the reference classes are
passed-by-value and represent objects. If we want our account and other
classes of objects to be represented by some custom indirect references
then we need to define the corresponding reference class:

::

    reference Persistent {
      int primaryKey; 
    }

It includes one integer field which is this object primary key in some
database. In order to automatically resolve this reference the reference
class needs a so called *continuation method*.

::

    reference Persistent { 
      int primaryKey; 
      void continue() { 
        Object o = resolve(primaryKey); 
        o.continue(); 
        unresolve(o); 
      } 
    }

Notice that this reference class is unaware of any object class it will
represent. So it can be used to represent any class of objects including
Account and Customer.

**Step 3**

Now we have some target classes we want to represent indirectly such as
Account and Customer and a reference class which is able to indirectly
represent other objects. In order to specify how objects of various
classes have to be represented we use a so called *inclusion relation*
(which generalizes inheritance).

::

    class Account in Persistent { 
      double balance = 0; 
      double getBalance() { return balance; } 
    }

From this definition the compiler can easily learn that this object
class has to be represented by references in the format of the reference
class Persistent. Notice that this object class does not include any
information on its identity and other details of the representation and
access mechanism. Hence we can easily change the way it is represented
by including in some other reference class. In any case the following
statements

::

    Account account = customer.getAccount(); 
    double balance = account.getBalance();

are executed transparently, i.e., we do not need to know how an object
is being represented in order to use it. All the peculiarities of the
object representation and access are hidden in the reference class and
these intermediate functions are executed seamlessly behind the scenes.
In particular, if the account objects will reside on Mars while the
customer objects somewhere else in the Universe the code of the program
will not change ? it is enough only to change the declarations. That is
one of the main goals of the concept-oriented programming. One important
consequence is that a great deal of the program complexity is
concentrated in the reference classes and these functions are never
called because they are executed automatically as other objects are
being accessed.

More information on this approach to programming can be found here:
http://conceptoriented.org
