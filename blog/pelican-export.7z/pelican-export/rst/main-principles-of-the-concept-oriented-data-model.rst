Main principles of the concept-oriented data model
##################################################
:date: 2008-12-05 05:54
:author: savinov
:category: com, Uncategorized
:slug: main-principles-of-the-concept-oriented-data-model
:status: published

Concept-oriented model is based on the following main principles:

1. Separation of physical and logical structures [duality]. In COM any
elements is defined as a member of two separate structures which are
referred to as physical and logical. The physical structure has a
hierarchical form and describes how elements are represented and
accessed. In particular, it determines the life-cycle of elements, how
they are identified and where they are stored physically. Once an
element has been created it cannot change its position in the physical
structure. The logical structure has a multidimensional hierarchical
form where each element has a number of parents and a number of
children. Cycles are not permitted and there exist two special elements:
the top and the bottom. A list of parents (superelements) is stored as
properties of this element and hence it is possible to change them.
According to this separation each element is a member of two sets: one
is its physical parent while the other are its logical parents.

2. Priority of order of elements [order]. In COM it is of crucial
importance how elements are ordered rather than how they are organized
into sets. This means that the meaning of any element is determined by
its relative position to other elements in the logical structure where
it has a number of parents and children. The element itself without its
neighbours is meaningless because its position in the physical structure
has normally a primitive semantics. In contrast to set-based approaches,
in COM elements are ordered and only after that the sets are derived (a
set consists of all children of one parent).

3. Managing links rather than elements. Since semantics is determined by
the order of elements, the primary concern of any concept-oriented
database management system consists in managing this order. This means
that the links among elements are more important than the elements
themselves.

4. Syntax and semantics. In COM syntax is defined as constraints imposed
on possible properties of items imposed by concepts where items are
physical children of concepts. Specifically, if a concept has a number
of parent concepts (superconcepts) then its items have a syntactic
constraint. This constraint means that all items must have superitems
from these superconcepts.
