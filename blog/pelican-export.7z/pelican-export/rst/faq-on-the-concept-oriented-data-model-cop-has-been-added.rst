FAQ on the concept-oriented data model (COM) has been added
###########################################################
:date: 2008-11-29 13:48
:author: savinov
:category: com, Uncategorized
:slug: faq-on-the-concept-oriented-data-model-cop-has-been-added
:status: published

I have just added new FAQ into my
`conceptoriented.org <http://conceptoriented.org/>`__ portal. This new
COM FAQ answers such questions as what is the concept-oriented data
model (COM) syntax and semantics, what are concepts and items,
dimensions and realationships, grouping and aggregation. It also covers
some implementation issues and provides a comparison with other database
models and data modeling approaches.
