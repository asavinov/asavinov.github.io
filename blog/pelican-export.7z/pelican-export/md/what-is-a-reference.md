Title: What is a reference?
Date: 2008-11-29 13:51
Author: savinov
Category: cop, Uncategorized
Slug: what-is-a-reference
Status: published

Here are some fundamental characteristics of references:

-   Reference does not have a concrete position in space and hence does
    not have its own reference, i.e., references represent themselves by
    value
-   Reference exists within objects as their parts (fields) where it has
    a concrete position, which is not a reference (it is an offset). In
    other words, objects are identified by references within a container
    while references are identified by positins within an object.
-   References are passed by value and can exist in different objects so
    that references are travelling things (in contrast to objects which
    have a constant position in space).
-   References may have an internal structure (just like objects)

