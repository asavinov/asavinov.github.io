Title: FAQ on the concept-oriented programming (COP) updated
Date: 2008-11-29 13:55
Author: savinov
Category: cop, Uncategorized
Slug: faq-on-the-concept-oriented-programming-cop-updated
Status: published

I have added two new sections to [COP
FAQ](http://conceptoriented.org/faqs/cop-faq.html).\
The first added section on object creation and deletion answers
questions concerning object life-cycle management. The second added
section provides examples of Hello World programs which demonstrate
various principles of the concept-oriented programming.

More information on these and other concept-oriented\
technologies can be found on the [\
concept-oriented portal](http://conceptoriented.org/). In particular,
questions on these next generation technologies can be asked on the
recently opened\
[forum](http://conceptoriented.org/forums/index.php).
