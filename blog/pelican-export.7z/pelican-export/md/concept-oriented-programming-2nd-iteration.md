Title: Concept-oriented programming: 2nd iteration
Date: 2008-11-29 13:39
Author: savinov
Category: cop, Uncategorized
Slug: concept-oriented-programming-2nd-iteration
Status: published

The first version of COP I described this summer was rather general and
provided only main principles with generic exemples and use cases. Since
then I have collected much more material and made significant advances
so it makes sense to make the second iteration in order to fix the state
of the process. So I started to write new larger and deeper paper where
I am going to describe in details general principles of concept-oriented
programming, specify new version of ConceptJ, and provide more examples,
use cases and design patterns. Although some important features are
still absent the paradigm and the language are much more expressive now
(but still extremely simple) and can already be applied to develop real
world systems. I hope I will be able to finish it in reasonable time...
