Title: New wiki devoted to the concept-oriented programming (COP)
Date: 2008-11-29 14:18
Author: savinov
Category: cop, Uncategorized
Slug: new-wiki-devoted-to-the-concept-oriented-programming
Status: published

New [wiki](http://conceptoriented.org/wiki/) has been started on the
[concept-oriented portal](http://conceptoriented.org/). It contains a
number of articles in the style of encyclopaedia defining main terms and
notions used in the concept-oriented paradigm. In particular, in
includes a category for the [concept-oriented
programming](http://conceptoriented.org/wiki/Category:Concept-oriented_programming)
and a category for the [concept-oriented data
model](http://conceptoriented.org/wiki/Category:Concept-oriented_model).
