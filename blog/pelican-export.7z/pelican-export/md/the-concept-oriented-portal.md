Title: The Concept-Oriented Portal
Date: 2008-11-29 13:44
Author: savinov
Category: Uncategorized
Slug: the-concept-oriented-portal
Status: published

Today I started my own web site <http://conceptoriented.org/> for
collecting all information about the concept-oriented approach to
programming, database model, analysis and design. Currently it includes
only very limited information on the concept-oriented data model (COM)
but I will try to update this site regularly. The next thing is to add
more information on the general concept-oriented principles and COM faq.
