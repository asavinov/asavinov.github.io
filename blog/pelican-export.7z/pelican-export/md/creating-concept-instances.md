Title: Creating concept instances
Date: 2008-11-29 13:59
Author: savinov
Category: cop, Uncategorized
Slug: creating-concept-instances
Status: published

A *concept* in the concept-oriented programming (COP) is a pair of two
classes: an *object class* and a *reference class*. For example, concept
Account could be defined as follows:

    concept Account 
      reference {
        String accountNumber; 
        ... // Other fields and methods 
      }
      class {
        double balance; 
        ... // Other fields and methods 
      }

All members in this concept are broken into two groups: the members of
the reference class and the members of the object class.

Concepts are used as classes when declaring variables, parameters or
fields:

    Account myAccount;

However, in contrast to OOP, each instance of a concept produces two
instances: an instance of the reference class, called reference, and an
instance of the object class, called object. The idea here is that the
new reference is stored directly in the variable while the new object is
created in some storage. Thus references and objects live in two worlds:
references are stored and passed by value while objects are stored and
passed by reference only.

If we create a new account

    Account myAccount = new Account();

then variable myAccount will contain an account number, which is a field
of the reference class. The account itself is created in some storage,
e.g., in memory or in a database. Thus the account can be accessed only
by means of information stored in its reference. For example, let us
assume that we need to get the account balance:

    myAccount.getBalance();

Notice however that this variable contains an account number rather than
a direct (native) reference. So how the account object can be accessed?
A short answer is that this reference has to be resolved and only after
the native reference is restored the object can be accessed.

An advantage of such a division onto a reference class and an object
class is that we can effectively separate two concerns:

-   object business methods (OBM) and
-   object representation and access (ORA).

Any object is represented and accessed *indirectly* using its custom
references which are defined in a reference class of some concept. Yet
the object represented by is reference is accessed *transparently* just
like in OOP. For example, we can serialize this account reference and
after loading it back again the reference is still valid because it is
actually the account number rather than a native reference. The
programmer can use objects as usual by calling its methods while all the
intermediate functionality will be executed automatically behind the
scenes.

More information on this approach to programming can be found here:
<http://conceptoriented.org>
