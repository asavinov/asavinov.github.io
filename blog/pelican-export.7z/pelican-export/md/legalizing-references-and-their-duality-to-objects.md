Title: Legalizing references and their duality to objects
Date: 2008-11-29 14:14
Author: savinov
Category: cop, Uncategorized
Slug: legalizing-references-and-their-duality-to-objects
Status: published

One of the main principles of the concept-oriented paradigm is that of
*duality*. One of its consequences is that an element is described using
two classes: a reference class and an object class. And instead of a
single world of objects in OOP, we get a new world consisting of the
realm of references and the realm of objects. An object is considered a
*thing in itself* which is not directly accessible. A reference on the
other hand is available directly and provides a mechanism for accessing
objects. Thus programming and data management is the process of
manipulating references which *indirectly* represent objects. In this
case it is important to *legalize reference* by making them first class
citizens. This particularly means that there have to be means for
modelling behaviour of objects *and* references rather than only
objects.

In the concept-oriented paradigm this legalization is performed by
introducing [concepts](http://c2.com/cgi/wiki?ConceptInCop) as a
generalization of conventional classes. Concept is a pair consisting of
one reference class and one object class. Instances of the reference
class exist in the realm of references. They are passed-by-value and do
not have their own references. Instances of the object class exist in
the realm of objects. They are passed-by-reference using their
representatives from the realm of references. It is important that
concepts allow us to model objects and references in their inseparable
unity.

Having a reference is the primary and necessary thing for anything that
wants to exhibit itself as an *existing* thing. In other words, without
a reference it is simply not possible to let others know that this
object does really exist. Thus describing an object in OOP via its
object class is not enough for this object to be perceptible and hence
useful. In OOP this problem is solved by providing a native class of
references which is "inherited" by any other object class. In the
[concept-oriented
programming](http://c2.com/cgi/wiki?ConceptOrientedProgramming) (COP)
any object class may declare its own reference class using the new
programming construct, called
[concept](http://conceptoriented.org/wiki/Concept_%28concept-oriented_programming%29).
An important thing here is that the two classes are always defined in
pairs and hence we can retain their inseparability and mutual
dependence. References provide a front end for the objects they
represent while objects may possess some behaviour that needs to be
associated with the concrete points in space.
