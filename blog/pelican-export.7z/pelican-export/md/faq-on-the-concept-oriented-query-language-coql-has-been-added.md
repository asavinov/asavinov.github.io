Title: FAQ on the Concept-Oriented Query Language (COQL) has been added
Date: 2008-11-29 13:49
Author: savinov
Category: com, Uncategorized
Slug: faq-on-the-concept-oriented-query-language-coql-has-been-added
Status: published

I have just added new FAQ into my
[conceptoriented.org](http://conceptoriented.org/) portal, which answers
simple questions concerning the Concept-Oriented Query Language (COQL).
COQL is one possible query language suitable for the use in the
concept-oriented data model.

I also started a thread in <http://www.dbforums.com/> where this model
can be discussed. Here is the link:
<http://www.dbforums.com/t1072076.html>
