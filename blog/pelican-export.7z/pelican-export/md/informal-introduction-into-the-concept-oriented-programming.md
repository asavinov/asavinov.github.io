Title: Informal Introduction into the Concept-Oriented Programming
Date: 2008-11-29 14:21
Author: savinov
Category: cop, Uncategorized
Slug: informal-introduction-into-the-concept-oriented-programming
Status: published

**Title:** [Informal Introduction into the Concept-Oriented
Programming](http://conceptoriented.org/papers/CopInformalIntroduction.html)

**Absract:** This paper describes a new approach to programming, called
the concept-oriented programming (COP). It is based on using a new
programming construct, called
[concept](http://conceptoriented.org/wiki/Concept_%28concept-oriented_programming%29),
which generalizes conventional classes. Concepts describe behaviour of
both objects and references. Hence references are completely legalized
and made first-class citizens with the same rights as objects. Using
concepts the programmer can easily describe custom virtual address
spaces where objects will exist. The hierarchical structure of such a
space is modelled by means of concept [inclusion
relation](http://conceptoriented.org/wiki/Inclusion_%28concept-oriented_programming%29)
which generalizes class inheritance. In COP, a great deal or even most
of functions are executed implicitly during object access rather than in
target objects themselves. These functions have cross-cutting nature but
can be effectively separated using COP.

**COP Wiki:**
<http://conceptoriented.org/wiki/Category:Concept-oriented_programming>

**COP FAQ:** <http://conceptoriented.org/faqs/cop-faq.html>

**COP forum:** <http://conceptoriented.org/forums/index.php>
