Title: Two versions of the concept-oriented programming: COP-I and COP-II
Date: 2008-11-29 14:12
Author: savinov
Category: cop, Uncategorized
Slug: two-versions-of-the-concept-oriented-programming
Status: published

[Concept](http://conceptoriented.org/wiki/Concept_(concept-oriented_programming))
is the main programming construct in the [concept-oriented
programming](http://conceptoriented.org/wiki/Concept-oriented_programming)
(COP) which is defined as a pair of two classes: one *reference class*
and one *object class*. The object class describes structure and
functions of *objects* which are passed-by-reference. The reference
class describes structure and functions of *references* which are
passed-by-value and represent objects. Thus we distinguish two kinds of
things: (i) objects characterized by some identifiers and (ii)
references representing and providing access to objects. These two kinds
of things are connected by the 'represents' (or 'represented by')
relation. Then the following question arises: **how objects and
references of different concepts relate to each other, i.e., who
represents whom**.

Taking into account some natural constraints, there exist the following
major alternatives:

-   **COP-I:** Objects of a concept are *represented by* references of
    the parent concept. Or, equally, references of a concept *represent*
    objects of the child concepts.
-   **COP-II:** Objects of a concept are *represented by* references of
    this same concept. Or, equally, references of a concept *represent*
    objects of this same concept.

For example, let us assume that we want to describe account objects and
account references using concepts. Using COP-I it will be written as
follows:

    concept Bank 
      object { 
        ...
      }
      reference { // Represents objects of child concepts (Account, ...) 
        String accountNumber; 
        ...
      }

    concept Account in Bank 
      object { // Represented by references of the parent concept (Bank) 
        double balance; 
        ...
      }
      reference { 
        ...
      }

Notice that here we need two concepts. References of the Bank concept
represent objects of the Account concept. Thus concept is used to
describe a class of objects along with the references used to
represented *internal* objects existing in this context. For each object
of the concept there exist many references of this concept (created to
represent child objects). Essentially concepts are used to describe
containers with their own internal identifiers. It is one of the main
design goals of COP-I which is described in the following paper:
<http://conceptoriented.org/savinov/publicat/csjm_05.pdf>.

The following example demonstrates how the same can be written in
COP-II:

    concept Account 
      reference { // Represents objects of this concept (below) 
        String accountNumber; 
        ...
      }
      object { // Represented by references of this concept (above) 
        double balance; 
        ...
      }

Here one and the same concept describes both objects and references used
to represent them. There is one-to-one correspondence between references
and objects of one concept. This approach is described in this paper:
<http://conceptoriented.org/savinov/publicat/imi-report_07.pdf>.

To (visually) distinguish these two approaches we change the order in
which object class and reference class are written in the concept
definition. In COP-I we write the object class and then the reference
class (first example). In COP-II we write the reference class and then
the object class (second example).

[The Concept-Oriented Portal](http://conceptoriented.org)
