Title: What is an object?
Date: 2008-11-29 13:50
Author: savinov
Category: cop, Uncategorized
Slug: what-is-an-object
Status: published

Here are some fundamental characteristics of objects:

-   Each object has a concrete position in space, which is constant and
    cannot be changed. Having a position or coordinate means also object
    existence. Objects are created with some position and then die in
    the same position.
-   Objects exhibit (represent) themselves in other contexts (parts of
    the spaces) indirectly via references (which are not objects because
    do have concrete position in space). Thus we never know what an
    object is in reality because the only thing we have is a reference.
-   In addition to existence objects have their semantics, which is
    defined as a combination of other objects, which are normally
    represented by reference. Thus semantically an object is simply a
    combination of other objects.
-   Objects are indivisible things just because they have a concrete
    position in space. We cannot separate their semantic constituents.
    The only thing that can be separated is object reference. Moreover,
    the fact that several objects have one and the same coordinate makes
    them a new object. In other words, an ability of parts to be placed
    in one point underlies the mechanism of object construction.

