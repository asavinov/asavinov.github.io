Title: FAQ on the Concept-Oriented Programming
Date: 2008-11-29 14:16
Author: savinov
Category: cop, Uncategorized
Slug: faq-on-the-concept-oriented-programming
Status: published

A new [FAQ](http://conceptoriented.org/faqs/cop-faq.html) has been
started in the series of concept-oriented technology FAQs on the
[concept-oriented portal](http://conceptoriented.org/). This new
[FAQ](http://conceptoriented.org/faqs/cop-faq.html) is aimed at
answering simple questions on the next generation programming paradigm
called the [concept-oriented
programming](http://conceptoriented.org/wiki/Concept-oriented_programming)
(COP). This new approach is based on a set of principles which are
explained in the first section. The main programming construct in COP is
a
[concept](http://conceptoriented.org/wiki/Concept_(concept-oriented_programming))
which generalizes conventional classes. What is a concept, what are its
properties and how it is used is described in the second section of the
[COP FAQ](http://conceptoriented.org/faqs/cop-faq.html). More
information on the concept-oriented programming can be found in the
recently published paper which can also be downloaded from the
[concept-oriented portal](http://conceptoriented.org/). The portal also
provides information on other related concept-oriented technologies such
as the concept-oriented data model (COM).
